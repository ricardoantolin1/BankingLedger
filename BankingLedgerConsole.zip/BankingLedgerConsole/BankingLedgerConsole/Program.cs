﻿using BankingCore;
using System;

namespace BankingLedgerConsole
{
    public enum Command { None = 0, NewAccount = 1, Login = 2, Deposit = 3, Withdraw = 4, CheckBalance = 5, TransactionHistory = 6, Logout = 7 };

    public class Program
    {
        public const string LoggedInOptions = "PLEASE SELECT:\n(1) New Account\n(2) Login\n(3) Deposit\n(4) Withdraw\n(5) Check Balance\n(6) Transaction History\n(7) Logout";
        public const string LoggedOutOptions = "PLEASE SELECT:\n(1) New Account\n(2) Login"; 

        public static void Main(string[] args)
        {
            Console.Title = "Banking Ledger";
            RunProgram(); 
        }

        public static void RunProgram()
        {
            Bank Bank = new Bank(); 

            while (true)
            {
                string prompt = Bank.IsUserLoggedIn() ? LoggedInOptions : LoggedOutOptions;
                Command Command = ReadMenuSelection(prompt);
                
                try
                {
                    string result = Execute(Bank, Command);
                    Console.WriteLine(result + "\n");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message + "\n");
                }
            }
        }

        public static Command MapCommandToUserSelection(char userInput)
        {
            int optionSelected = 0;
            if (Int32.TryParse(userInput.ToString(), out optionSelected))
            {
                return (Command)optionSelected;
            }

            return Command.None; 
        }

        public static string ReadUserInput(string prompt = "")
        {
            string userInput = String.Empty;

            Console.Write(">" + prompt);
            while (String.IsNullOrEmpty(userInput))
            {
                userInput = Console.ReadLine();
            }

            return userInput;
        }

        public static Command ReadMenuSelection(string prompt = "")
        {
            Console.Write(prompt + "\n>");
            char userInput = Console.ReadKey().KeyChar;

            return MapCommandToUserSelection(userInput);
        }

        public static void WriteMenuHeading(string menuHeading)
        {
            Console.WriteLine("\n\n" + menuHeading.ToUpper() + ":");
        }

        public static string Execute(Bank Bank, Command Command)
        {
            string message = String.Empty; 

            switch (Command)
            {
                case Command.NewAccount:
                    WriteMenuHeading("New Account");
                    var username = ReadUserInput("Username: ");
                    var password = ReadUserInput("Password: ");
                    message = Bank.CreateAccount(username, password);
                    break;
                case Command.Login:
                    WriteMenuHeading("Login");
                    username = ReadUserInput("Username: ");
                    password = ReadUserInput("Password: ");
                    message = Bank.Login(username, password);
                    break;
                case Command.Deposit:
                    WriteMenuHeading("Deposit");
                    var amount = ReadUserInput("Amount: $");
                    message = Bank.Deposit(amount);
                    break;
                case Command.Withdraw:
                    WriteMenuHeading("Withdraw");
                    amount = ReadUserInput("Amount: $");
                    message = Bank.Withdraw(amount);
                    break;
                case Command.CheckBalance:
                    WriteMenuHeading("Balance");
                    string balance = Bank.Balance();
                    message = String.Format("Your balance is: {0}", balance);
                    break;
                case Command.TransactionHistory:
                    WriteMenuHeading("Transaction History");
                    message = Bank.TransactionHistory();
                    break;
                case Command.Logout:
                    WriteMenuHeading("Logout");
                    message = Bank.Logout();
                    break;
            }

            return message;
        }
    }
}
