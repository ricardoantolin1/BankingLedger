﻿using System.Collections.Generic;
using System.Linq;

namespace BankingCore
{
    public class Account
    {
        private readonly string _username;
        private readonly string _password;

        public string Username { get { return _username; } }
        public string Password { get { return _password; } }
        public List<Transaction> Transactions { get; set; }
      
        public Account(string username, string password)
        {
            _username = username;
            _password = password;
            Transactions = new List<Transaction>();
        }

        public void AddTransaction(Transaction transaction)
        {
            Transactions.Add(transaction);
        }

        public decimal CurrentBalance()
        {
            decimal withdrawalTotal = Transactions.Where(t => t.TransactionType == TransactionType.Withdraw).Sum(w => w.Amount);
            decimal depositTotal = Transactions.Where(t => t.TransactionType == TransactionType.Deposit).Sum(w => w.Amount);
            
            return depositTotal - withdrawalTotal; 
        }
    } 
}
