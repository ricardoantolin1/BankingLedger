﻿using System;
using System.Linq;

namespace BankingCore
{
    public class Bank
    {
        public Ledger Ledger { get; set;}
        public Account Account { get; set; }

        public Bank()
        {
            this.Ledger = new Ledger();
        }

        public bool IsUserLoggedIn()
        {
            return (this.Account != null);
        }

        public string CreateAccount(string username, string password)
        {
            if (!this.Ledger.ValidUsername(username))
            {
                return String.Format("Invalid username: \"{0}\"", username);
            }
            if (this.Ledger.UsernameExists(username))
            {
                return String.Format("Username already exists: \"{0}\"", username);
            }

            this.Ledger.AddAccount(username, password);

            return String.Format("Account Created: \"{0}\"", username);
        }

        public string Login(string username, string password)
        {
            var account = this.Ledger.GetAccount(username, password);

            if (account != null)
            {
                this.Account = account;
                return String.Format("Welcome! User \"{0}\" is logged in.", username);
            }

            return String.Format("Username/Password combination does not exist.", username);
        }

        public string Logout()
        {
            if (this.Account == null)
            {
                return "No user logged in.";
            }

            var message = String.Format("User \"{0}\" logged out.", this.Account.Username);
            this.Account = null;

            return message;
        }

        public string Deposit(string inputAmount)
        {
            if (this.Account == null)
            {
                return "No user logged in.";
            }

            decimal amount;
            if (Decimal.TryParse(inputAmount, out amount) && amount > 0m && !ContainsFractionsOfCents(amount))
            {
                var transaction = new Transaction(TransactionType.Deposit, Convert.ToDecimal(inputAmount));
                this.Ledger.AddTransaction(this.Account, transaction);

                return String.Format("User \"{0}\" deposited {1}.", this.Account.Username, String.Format("{0:C}", amount));
            }
            else
            {
                return "Invalid amount.";
            }
        }

        public string Withdraw(string inputAmount)
        {
            if (this.Account == null)
            {
                return "No user logged in.";
            }

            decimal amount;
            if (Decimal.TryParse(inputAmount, out amount) && amount > 0m && !ContainsFractionsOfCents(amount))
            {
                // check whether funds are available
                if (amount > this.Account.CurrentBalance())
                {
                    return "Insufficient funds.";
                }

                var transaction = new Transaction(TransactionType.Withdraw, Convert.ToDecimal(inputAmount));
                this.Ledger.AddTransaction(this.Account, transaction);

                return String.Format("User \"{0}\" withdrew {1}.", this.Account.Username, String.Format("{0:C}", amount));
            }
            else
            {
                return "Invalid amount.";
            }
        }

        public string Balance()
        {
            if (this.Account == null)
            {
                return "No user logged in.\n";
            }

            return String.Format("{0:C}", this.Account.CurrentBalance());
        }

        public string TransactionHistory()
        {
            if (this.Account == null)
            {
                return "No user logged in.\n";
            }

            return String.Join("\n", this.Account.Transactions.Select(t => t.ToString()));
        }

        private bool ContainsFractionsOfCents(decimal amount)
        {
            return Math.Round(amount, 2) != amount;
        }
    }
}
