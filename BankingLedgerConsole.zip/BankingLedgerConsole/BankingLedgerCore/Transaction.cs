﻿using System;

namespace BankingCore
{
    public enum TransactionType { Withdraw, Deposit };

    // immutable
    public class Transaction
    {
        private readonly TransactionType _transactionType;
        private readonly decimal _amount;
        private readonly DateTime _timestamp;

        public Transaction(TransactionType transactionType, decimal amount)
        {
            this._transactionType = transactionType;
            this._amount = amount;
            this._timestamp = DateTime.Now;
        }

        public TransactionType TransactionType { get { return _transactionType; } }
        public decimal Amount { get { return _amount; } }
        public DateTime Timestamp { get { return _timestamp; } }

        public override string ToString()
        {
            return this.Timestamp.ToString("MM/dd/yyyy HH:mm:ss") + " " + 
                this.TransactionType.ToString() + " " + 
                String.Format("{0:C}", this.Amount); 
        }
    }

}
