﻿using System.Collections.Generic;
using System.Linq;

namespace BankingCore
{
    public class Ledger
    {
        public List<Account> Accounts { get; set; }

        public Ledger()
        {
            this.Accounts = new List<Account>(); 
        }

        public bool UsernameExists(string username)
        {
            return this.Accounts.Where(a => a.Username == username).Any();
        }

        public bool ValidUsername(string username)
        {
            // alphanumeric usernames only
            return username.All(char.IsLetterOrDigit);
        }

        public void AddAccount(string username, string password)
        {
            var account = new Account(username, password);
            this.Accounts.Add(account);
        }

        public void AddTransaction(Account account, Transaction transaction)
        {
            account.AddTransaction(transaction);
        }

        public decimal GetBalance(Account account)
        {
            return account.CurrentBalance();
        }

        public Account GetAccount(string username, string password)
        {
            return this.Accounts.Where(a => a.Username == username && a.Password == password).SingleOrDefault();
        }
    }
}